/*
 * Fallout Chat Mod — experimental Vortex installer extension (PROOF OF CONCEPT)
 * ----------------------------------------------------------------------------
 * Adds a button to Vortex's top toolbar that:
 *   1. GETs https://falloutchatmod.com/api/releases  (newest release is data[0])
 *   2. Builds the raw signed installer URL for that version
 *   3. Downloads it to a temp file
 *   4. Spawns it — the signed NSIS installer requests elevation itself (UAC)
 *
 * Both the installer (.exe) and this extension are hosted on falloutchatmod.com,
 * NOT on Nexus, so neither is subject to Nexus's installer-file quarantine.
 * This is the trade-off: it is therefore SIDELOAD-ONLY (drag the .zip into
 * Vortex → Extensions → "Drop File(s)"). A sideloaded extension does NOT appear
 * in Vortex's in-app extension browser — that requires Nexus review of the
 * manifest. See README.md for the full discovery / AV / maintenance caveats.
 *
 * Deliberately written in plain JS with Node built-ins for download + spawn
 * (no dependence on uncertain vortex-api executable/elevation signatures), so it
 * drops in and runs without a build step. Only well-established vortex-api
 * surfaces are used: registerAction, showDialog, sendNotification,
 * showErrorNotification, dismissNotification.
 */

const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const API_RELEASES = 'https://falloutchatmod.com/api/releases';
const DOWNLOADS_BASE = 'https://falloutchatmod.com/downloads/electron';
const NOTIF_ID = 'fcm-installer';

/**
 * Pure: build the raw Windows installer URL for a version.
 * Mirrors backend `rawWindowsInstallerUrl` — productName "Fallout Chat Mod"
 * (with spaces), URL-encoded. Exported for the tiny test in test-url.js.
 *   "1.3.91" -> ".../Fallout%20Chat%20Mod%20Setup%201.3.91.exe"
 */
function rawWindowsInstallerUrl(version) {
  return `${DOWNLOADS_BASE}/${encodeURIComponent(`Fallout Chat Mod Setup ${version}.exe`)}`;
}

/** GET a URL following redirects; resolve with the full body as a string. */
function httpsGetText(url, redirectsLeft = 5) {
  return new Promise((resolve, reject) => {
    https
      .get(url, (res) => {
        const { statusCode, headers } = res;
        if (statusCode >= 300 && statusCode < 400 && headers.location) {
          if (redirectsLeft <= 0) return reject(new Error('Too many redirects'));
          res.resume();
          const next = new URL(headers.location, url).toString();
          return resolve(httpsGetText(next, redirectsLeft - 1));
        }
        if (statusCode !== 200) {
          res.resume();
          return reject(new Error(`HTTP ${statusCode} for ${url}`));
        }
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (c) => (body += c));
        res.on('end', () => resolve(body));
      })
      .on('error', reject);
  });
}

/** Download a URL to destPath, following redirects. Resolves with destPath. */
function downloadTo(url, destPath, onProgress, redirectsLeft = 5) {
  return new Promise((resolve, reject) => {
    https
      .get(url, (res) => {
        const { statusCode, headers } = res;
        if (statusCode >= 300 && statusCode < 400 && headers.location) {
          if (redirectsLeft <= 0) return reject(new Error('Too many redirects'));
          res.resume();
          const next = new URL(headers.location, url).toString();
          return resolve(downloadTo(next, destPath, onProgress, redirectsLeft - 1));
        }
        if (statusCode !== 200) {
          res.resume();
          return reject(new Error(`HTTP ${statusCode} downloading installer`));
        }
        const total = Number(headers['content-length'] || 0);
        let received = 0;
        const file = fs.createWriteStream(destPath);
        res.on('data', (chunk) => {
          received += chunk.length;
          if (onProgress && total) onProgress(Math.round((received / total) * 100));
        });
        res.pipe(file);
        file.on('finish', () => file.close(() => resolve(destPath)));
        file.on('error', (err) => {
          fs.unlink(destPath, () => reject(err));
        });
      })
      .on('error', reject);
  });
}

/** GET /api/releases and return the newest version string (data[0].version). */
async function fetchLatestVersion() {
  const json = JSON.parse(await httpsGetText(API_RELEASES));
  const releases = json && json.data;
  if (!Array.isArray(releases) || releases.length === 0) {
    throw new Error('No releases returned by the API');
  }
  // The API returns releases most-recent-first.
  const version = releases[0].version;
  if (!version) throw new Error('Latest release has no version');
  return version;
}

async function installFlow(api) {
  if (process.platform !== 'win32') {
    api.sendNotification({
      id: NOTIF_ID,
      type: 'warning',
      title: 'Fallout Chat Mod',
      message: 'The Windows installer can only be run on Windows.',
    });
    return;
  }

  const confirm = await api.showDialog(
    'question',
    'Install Fallout Chat Mod',
    {
      text:
        'This will download the latest Fallout Chat Mod overlay installer from ' +
        'falloutchatmod.com and run it. Windows will ask for permission (UAC) to ' +
        'complete the install. Continue?',
    },
    [{ label: 'Cancel' }, { label: 'Download & Install' }],
  );
  if (confirm.action !== 'Download & Install') return;

  api.sendNotification({
    id: NOTIF_ID,
    type: 'activity',
    title: 'Fallout Chat Mod',
    message: 'Checking for the latest version…',
  });

  const version = await fetchLatestVersion();
  const url = rawWindowsInstallerUrl(version);
  const dest = path.join(os.tmpdir(), `Fallout Chat Mod Setup ${version}.exe`);

  api.sendNotification({
    id: NOTIF_ID,
    type: 'activity',
    title: `Fallout Chat Mod ${version}`,
    message: 'Downloading installer… 0%',
  });

  await downloadTo(url, dest, (pct) => {
    api.sendNotification({
      id: NOTIF_ID,
      type: 'activity',
      title: `Fallout Chat Mod ${version}`,
      message: `Downloading installer… ${pct}%`,
    });
  });

  // Launch the signed NSIS installer. It requests elevation itself (its manifest
  // has RequestExecutionLevel admin), so Windows shows the UAC prompt — we do not
  // need vortex-run's runElevated for the PoC. Detach so it outlives Vortex.
  const child = spawn(dest, [], { detached: true, stdio: 'ignore' });
  child.unref();

  api.sendNotification({
    id: NOTIF_ID,
    type: 'success',
    title: `Fallout Chat Mod ${version}`,
    message: 'Installer launched — follow the on-screen prompts (approve the UAC dialog).',
    displayMS: 8000,
  });
}

function init(context) {
  // Top toolbar icon — visible regardless of which game is being managed
  // (this extension is game-agnostic; it installs the desktop overlay, not a mod).
  context.registerAction(
    'global-icons',
    300,
    'download',
    {},
    'Install Fallout Chat Mod',
    () => {
      installFlow(context.api).catch((err) => {
        context.api.dismissNotification(NOTIF_ID);
        context.api.showErrorNotification('Fallout Chat Mod install failed', err, {
          allowReport: false,
        });
      });
    },
  );

  return true;
}

module.exports = { default: init };
// Exported for tests/harnesses (Node can require this file; init() is only called
// by Vortex). The download/spawn path is exercised headlessly by mechanism-test.js.
module.exports.rawWindowsInstallerUrl = rawWindowsInstallerUrl;
module.exports.httpsGetText = httpsGetText;
module.exports.downloadTo = downloadTo;
module.exports.fetchLatestVersion = fetchLatestVersion;
